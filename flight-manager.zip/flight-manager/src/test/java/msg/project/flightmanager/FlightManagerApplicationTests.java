package msg.project.flightmanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
